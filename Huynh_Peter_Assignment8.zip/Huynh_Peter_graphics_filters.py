"""
Filename: Huynh_Peter_simple_graphics_fiters.py
Assignment Name: Assignment Eight: Images and Filters
Author: Peter Tran Huynh
Description: The file contains functions of graphical image filters and a function to display gifs within a bordered window
"""

from graphics import *

def DisplayImg(gif):					
	"""
	Displays unfiltered gif image
	"""
	border = 30										# Variable for border around image
	img = Image(Point(0, 0), gif)					# Variable set for making the gif able to display
	w = img.getWidth()								# Variable set to gif width
	h = img.getHeight()								# Variable set to gif height
	
	# Using the Image width and height, a window of correct size is created for displaying the image file
	win = GraphWin(gif, w + 2 * border, h + 2 * border)
	
	img.move(w // 2 + border, h // 2 + border)		# Moves the image anchor point to the center of the window
	img.draw(win)									# Draws the image to the window
	win.getMouse()									# Gets input from mouse device
	win.close()										# Closes window
	return img										# Returns new image

def Grayscale(gif):
	"""
	Changes an image to only contain shades of gray (this is in no way related to a book)
	"""
	border = 30																				# Variable for border around image
	img = Image(Point(0, 0), gif)															# Variable set for making the gif able to display
	w = img.getWidth()																		# Variable set to gif width
	h = img.getHeight()																		# Variable set to gif height
	
	# Using the Image width and height, a window of correct size is created for displaying the image file
	win = GraphWin(("Grayscaled " + gif), w + 2 * border, h + 2 * border)

	for row in range(w):																	# Loops through every row
		for column in range(h):																# Loops through every column while looping through every row
			r, g, b = img.getPixel(row, column)												# Sets variable r, g, and b to pixel at point of (row, column)
			brightness = int(round(0.3 * r + 0.3 * g + 0.3 * b))							# Sets variable brightness to integer of a rounded amount of a fraction of the sum of r, g, b, making it closer to black and less of it's pure color.
			img.setPixel(row, column, color_rgb(brightness, brightness, brightness))		# Sets pixels in point (row, column) to the new color rgb set to the value of brightness
	
	img.move(w // 2 + border, h // 2 + border)												# Moves the image anchor point to the center of the window
	img.draw(win)																			# Draws the image to the window
	win.getMouse()																			# Gets input from mouse device
	win.close()																				# Closes window
	return img																				# Returns new image


def BlackWhite(gif):
	"""
	Changes an image so that it only contains black and white colors
	"""
	border = 30																				# Variable for border around image
	img = Image(Point(0, 0), gif)															# Variable set for making the gif able to display
	w = img.getWidth()																		# Variable set to gif width
	h = img.getHeight()																		# Variable set to gif height
	
	# Using the Image width and height, a window of correct size is created for displaying the image file
	win = GraphWin(("Black and White " + gif), w + 2 * border, h + 2 * border)

	for row in range(w):																	# Loops through every row
		for column in range(h):																# Loops through every column while looping through every row
			r, g, b = img.getPixel(row, column)												# Sets variable r, g, and b to pixel at point of (row, column)
			if r >= 128 or g >= 128 or b >= 128:											# Condition where if red, green, or blue is greater than or equal to 128 it will set brightness to 255.
				brightness = 255															# Sets brightness to 255 (pure color/all white) if the value of r, g, or b is closer to white
			else:																			# Other if the condition wasn't met.
				brightness = 0																# Sets brightness to 0 if r, g, and b are closer to black 
			img.setPixel(row, column, color_rgb(brightness, brightness, brightness))		# Sets pixels in point (row, column) to the new color rgb set to the value of brightness
	
	img.move(w // 2 + border, h // 2 + border)												# Moves the image anchor point to the center of the window
	img.draw(win)																			# Draws the image to the window
	win.getMouse()																			# Gets input from mouse device
	win.close()																				# Closes window
	return img																				# Returns new image

def RedTones(gif):
	"""
	Sucks all of the blue and green out of an image, leaving only the red behind
	"""
	border = 30													# Variable for border around image
	img = Image(Point(0, 0), gif)								# Variable set for making the gif able to display
	w = img.getWidth()											# Variable set to gif width
	h = img.getHeight()											# Variable set to gif height
	
	# Using the Image width and height, a window of correct size is created for displaying the image file
	win = GraphWin(("Red Toned " + gif), w + 2 * border, h + 2 * border)

	for row in range(w):										# Loops through every row
		for column in range(h):									# Loops through every column while looping through every row
			r, g, b = img.getPixel(row, column)					# Sets variable r, g, and b to pixel at point of (row, column)
			img.setPixel(row, column, color_rgb(r, 0, 0))		# Sets pixels in point (row, column) to the new color gb set to the value of 0, Retains red value.
	
	img.move(w // 2 + border, h // 2 + border)					# Moves the image anchor point to the center of the window
	img.draw(win)												# Draws the image to the window
	win.getMouse()												# Gets input from mouse device
	win.close()													# Closes window
	return img													# Returns new image

def GreenTones(gif):
	"""
	Similar to red tones, except different colors
	"""
	border = 30													# Variable for border around image
	img = Image(Point(0, 0), gif)								# Variable set for making the gif able to display
	w = img.getWidth()											# Variable set to gif width
	h = img.getHeight()											# Variable set to gif height
	
	# Using the Image width and height, a window of correct size is created for displaying the image file
	win = GraphWin(("Green Toned " + gif), w + 2 * border, h + 2 * border)

	for row in range(w):										# Loops through every row
		for column in range(h):									# Loops through every column while looping through every row
			r, g, b = img.getPixel(row, column)					# Sets variable r, g, and b to pixel at point of (row, column)
			img.setPixel(row, column, color_rgb(0, g, 0))		# Sets pixels in point (row, column) to the new color gb set to the value of 0, Retains green value.
	
	img.move(w // 2 + border, h // 2 + border)					# Moves the image anchor point to the center of the window
	img.draw(win)												# Draws the image to the window
	win.getMouse()												# Gets input from mouse device
	win.close()													# Closes window
	return img													# Returns new image

def BlueTones(gif):
	"""
	Hopefully you’ve got this pattern now
	"""
	border = 30													# Variable for border around image
	img = Image(Point(0, 0), gif)								# Variable set for making the gif able to display
	w = img.getWidth()											# Variable set to gif width
	h = img.getHeight()											# Variable set to gif height
	
	# Using the Image width and height, a window of correct size is created for displaying the image file
	win = GraphWin(("Blue Toned " + gif), w + 2 * border, h + 2 * border)

	for row in range(w):										# Loops through every row
		for column in range(h):									# Loops through every column while looping through every row
			r, g, b = img.getPixel(row, column)					# Sets variable r, g, and b to pixel at point of (row, column)
			img.setPixel(row, column, color_rgb(0, 0, b))		# Sets pixels in point (row, column) to the new color gb set to the value of 0, Retains blue value.
	
	img.move(w // 2 + border, h // 2 + border)					# Moves the image anchor point to the center of the window
	img.draw(win)												# Draws the image to the window
	win.getMouse()												# Gets input from mouse device
	win.close()													# Closes window
	return img													# Returns new image
	
def Posterize(gif):	
	"""
	Makes an image look more like a painting, where a large variety of color shades are smoothed out to fewer
	"""
	border = 30													# Variable for border around image
	img = Image(Point(0, 0), gif)								# Variable set for making the gif able to display
	w = img.getWidth()											# Variable set to gif width
	h = img.getHeight()											# Variable set to gif height
	
	# Using the Image width and height, a window of correct size is created for displaying the image file
	win = GraphWin(("Posterized " + gif), w + 2 * border, h + 2 * border)

	for row in range(w):										# Loops through every row
		for column in range(h):									# Loops through every column while looping through every row
			r, g, b = img.getPixel(row, column)					# Sets variable r, g, and b to pixel at point of (row, column)
			if r < 128:											# Condition where if the value of r, g ,or b is less than 128 it will be divided in half
				r = r // 2
			if g < 128:
				g = g // 2
			if b < 128:
				b = b // 2
			img.setPixel(row, column, color_rgb(r, g, b))		# Sets pixels in point (row, column) to the new color rgb set to the new values of R, G, B
	
	img.move(w // 2 + border, h // 2 + border)					# Moves the image anchor point to the center of the window
	img.draw(win)												# Draws the image to the window
	win.getMouse()												# Gets input from mouse device
	win.close()													# Closes window
	return img													# Returns new image

def Inverted(gif):
	"""
	Colors flip, this is really cool!
	"""
	border = 30													# Variable for border around image
	img = Image(Point(0, 0), gif)								# Variable set for making the gif able to display
	w = img.getWidth()											# Variable set to gif width
	h = img.getHeight()											# Variable set to gif height
	
	# Using the Image width and height, a window of correct size is created for displaying the image file
	win = GraphWin(("Inverted " + gif), w + 2 * border, h + 2 * border)

	for row in range(w):										# Loops through every row
		for column in range(h):									# Loops through every column while looping through every row
			r, g, b = img.getPixel(row, column)					# Sets variable r, g, and b to pixel at point of (row, column)
			r = 255 - r											# Inverts r, g, and b by setting them to 255 subtracted by their old values
			g = 255 - g
			b = 255 - b
			img.setPixel(row, column, color_rgb(r, g, b))		# Sets pixels in point (row, column) to the new color gb set to the inverted R,G,B values
	
	img.move(w // 2 + border, h // 2 + border)					# Moves the image anchor point to the center of the window
	img.draw(win)												# Draws the image to the window
	win.getMouse()												# Gets input from mouse device
	win.close()													# Closes window
	return img													# Returns new image

def ExtremePosterize(gif):
	"""
	Makes an image look more like a painting, where a large variety of color shades are smoothed out to fewer	
	"""
	border = 30													# Variable for border around image
	img = Image(Point(0, 0), gif)								# Variable set for making the gif able to display
	w = img.getWidth()											# Variable set to gif width
	h = img.getHeight()											# Variable set to gif height
	
	# Using the Image width and height, a window of correct size is created for displaying the image file
	win = GraphWin(("Extreme Posterized " + gif), w + 2 * border, h + 2 * border)

	for row in range(w):										# Loops through every row
		for column in range(h):									# Loops through every column while looping through every row
			r, g, b = img.getPixel(row, column)					# Sets variable r, g, and b to pixel at point of (row, column)
			if r < 128:											# Condition where if the value of r, g ,or b is less than 128 it will become 0
				r = 0
			if g < 128:
				g = 0
			if b < 128:
				b = 0
			if r >= 128:										# Condition where if the value of r, g ,or b is greater than or equal to 128 it will become 255
				r = 255
			if g >= 128:
				g = 255
			if b >= 128:
				b = 255
			img.setPixel(row, column, color_rgb(r, g, b))		# Sets pixels in point (row, column) to the new color rgb set to the new values of R,G,B
	
	img.move(w // 2 + border, h // 2 + border)					# Moves the image anchor point to the center of the window
	img.draw(win)												# Draws the image to the window
	win.getMouse()												# Gets input from mouse device
	win.close()													# Closes window
	return img													# Returns new image

def ColorFlippedBRG(gif):
	"""
	Colors flip mixing red as blue, green as red, and green as blue.
	"""
	border = 30													# Variable for border around image
	img = Image(Point(0, 0), gif)								# Variable set for making the gif able to display
	w = img.getWidth()											# Variable set to gif width
	h = img.getHeight()											# Variable set to gif height
	
	# Using the Image width and height, a window of correct size is created for displaying the image file
	win = GraphWin(("Color Flipped BRG " + gif), w + 2 * border, h + 2 * border)

	for row in range(w):										# Loops through every row
		for column in range(h):									# Loops through every column while looping through every row
			r, g, b = img.getPixel(row, column)					# Sets variable r, g, and b to pixel at point of (row, column)
			img.setPixel(row, column, color_rgb(b, r, g))		# Sets pixels in point (row, column) to mixed r, g, b values
	
	img.move(w // 2 + border, h // 2 + border)					# Moves the image anchor point to the center of the window
	img.draw(win)												# Draws the image to the window
	win.getMouse()												# Gets input from mouse device
	win.close()													# Closes window
	return img													# Returns new image

def ColorFlippedGBR(gif):
	"""
	Another colors flip, this is really cool!
	"""
	border = 30													# Variable for border around image
	img = Image(Point(0, 0), gif)								# Variable set for making the gif able to display
	w = img.getWidth()											# Variable set to gif width
	h = img.getHeight()											# Variable set to gif height
	
	# Using the Image width and height, a window of correct size is created for displaying the image file
	win = GraphWin(("Color Flipped GBR " + gif), w + 2 * border, h + 2 * border)

	for row in range(w):										# Loops through every row
		for column in range(h):									# Loops through every column while looping through every row
			r, g, b = img.getPixel(row, column)					# Sets variable r, g, and b to pixel at point of (row, column)
			img.setPixel(row, column, color_rgb(g, b, r))		# Sets pixels in point (row, column) to mixed r, g, b values
	
	img.move(w // 2 + border, h // 2 + border)					# Moves the image anchor point to the center of the window
	img.draw(win)												# Draws the image to the window
	win.getMouse()												# Gets input from mouse device
	win.close()													# Closes window
	return img													# Returns new image
