"""
Filename: Huynh_Peter_graphics_main.py
Assignment Name: Assignment Eight: Images and Filters
Author: Peter Tran Huynh
Description: The main file used to execute the graphics filters for the image files
Notes: Main file that calls other python file functions, and is the main structure for the program.
"""
from Huynh_Peter_graphics_filters import *
from os import listdir

def main():
	"""
	Main function that is the core structure of the program that calls all filters and external functions
	"""
	files = listdir(".")								# Variable Files is set to the directory graphics_main.py is in
	num = 0												# Integer variable set to be 0 as default
	userIn = 0											# Default user inputs
	userIn2 = 0
	userIn3 = 0
	userIn4 = 0
	fileName = ".default"								# Filename variable set to a default string
	whitelist = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'	# Whitelist used for what fileName can contain.
	
	gifDict = {}										# gifDict is an empty dictionary that will contain all gif filenames, filerDict is a dictionary containing filter options
	filterDict = {"1": "Grayscale", "2": "Black and White", "3": "Red Tone", "4": "Green Tone", "5": "Blue Tone", "6": "Posterize", "7": "Inverted", "8": "Extreme Posterize", "9": "Color Flip BRG", "10": "Color Flip GBR"}
	
	print("\nWelcome to the GIF image filter program!\n\nGIF Files in Directory:")	# Starting table prompt
	for name in files:									# Variable name is going through each file within the directory
		if name[-4:] == ".gif":							# Condition where the code will only execute if the files in the directory end with a .gif
			num += 1									# Increments num variable by 1 if there is a .gif file
			strnum = str(num)							# converts num into string to be set into dictionary
			for string in strnum:						# Loop is apparently required to set a string into the dictionary, bypasses KeyError 1
				gifDict[string] = name					# Adds the gif name tied to the command number into a dictionary
			print(strnum + "\t" + gifDict[strnum])		# Prints out one part of a prompted list of options
	print("20\tQuit")									# Prints command 20 as quit.
	
	while userIn != "20":												# First loop that loops until condition quit is met
		userIn = str(input("Enter Selection: "))						# First input user places in, used for gif selection
		if userIn in gifDict:											# If the user input is within the gif dictionary, the code will execute
			num = 0														# Resets num
			print("\nImage Filter Options:")							# prints table header
			for table in filterDict:									# Loops table in filter dictionary
				num += 1												# Increments 1 for num
				strnum = str(num)										# Converts num into a string and sets that into variable strnum
				print(strnum + ".\t" + filterDict[strnum])				# Prints strnum as the command, and the command associated to strnum within filter dictionary
			print("11.\tCancel")										# Prints command 11, which is cancel back to gif selection
			DisplayImg(gifDict[(userIn)])								# Displays unfiltered image
			
			while userIn2 != "10":											# Loops under the condition where if the second user input isn't command 10
				userIn2 = str(input("Enter Selection: "))					# Takes in users second input
				
				if userIn2 in filterDict:									# Condition where if the second input is within the filter dictionary the code will execute
					print("Working...")										# Prints Working...	
					if userIn2 == "1":										# Conditionals that execute specific filter dependent on user command input
						filterGif = Grayscale(gifDict[(userIn)])			# Sets filterGif variable to the function of the filter, which returns the filter image and displays it
					elif userIn2 == "2":
						filterGif = BlackWhite(gifDict[(userIn)])
					elif userIn2 == "3":
						filterGif = RedTones(gifDict[(userIn)])
					elif userIn2 == "4":
						filterGif = GreenTones(gifDict[(userIn)])
					elif userIn2 == "5":
						filterGif = BlueTones(gifDict[(userIn)])
					elif userIn2 == "6":
						filterGif = Posterize(gifDict[(userIn)])
					elif userIn2 == "7":
						filterGif = Inverted(gifDict[(userIn)])
					elif userIn2 == "8":
						filterGif = ExtremePosterize(gifDict[(userIn)])
					elif userIn2 == "9":
						filterGif = ColorFlippedBRG(gifDict[(userIn)])
					elif userIn2 == "10":
						filterGif = ColorFlippedGBR(gifDict[(userIn)])
					print("Done!")											# Prints Done!
					
					while userIn3 != "y" or userIn3 != "n":						# Third Loop that executes only while the condition of third user input isn't y or n 
						userIn3 = str(input("Save filtered image? (y/n): "))	# Takes in third input
						if userIn3 == "n":										# Condition where if the user enters n, the loop will break
							break
						elif userIn3 == "y":									# Condition where if the user enters y
							while fileName != ".conditionmet":					# Nested while loop used for user input for filename
								fileName = str(input("Enter filename for image (only letters and numbers): ")) 				# Takes input for filename of new gif file
								if fileName != (''.join(count for count in fileName if count in whitelist)):				# Condition checking if the input only has characters within the approved whitelist
									print("Invalid Choice - ", end = "")													# If there is a character not in the whitelist, then it is an invalid input
								else:																						# Else condition when filename is approved
									filterGif.save((fileName + ".gif"))														# Saved filtered gif as the filename in a gif format file
									print("Image saved as " + fileName + ".gif in same directory as original image.")		# Prints out the confirmation that the file is saved
									fileName = ".conditionmet"																# Sets the filename to a string to satisfy nested while loop condition
							break												# Breaks while loop for third input and file saving
						else:													# Else condition if user doesn't enter y or n, it is an invalid input and loops again
							print("Invalid Choice - ", end = "")				# Prints invalid choice before looping again
							
					while userIn4 != "y" or userIn4 != "n":											# Another while loop used to see if user wants to reloop for another image and filter
						userIn4 = str(input("Would you like to filter another image? (y/n): "))		# Takes in fouth user input
						if userIn4 == "n":															# Condition for if the user doesn't want to filter another gif, the program will set the command to 20 and autoquit
							print("Goodbye.")														# Prints goodbye
							userIn = "20"															# Sets user input to quit command
							break
						elif userIn4 == "y":														# If the user does want to filter another image, the program resets all command inputs
							userIn3 = "0"
							userIn2 = "0"
							userIn = "0"
							fileName = ".default"
							break
						else:
							print("Invalid Choice - ", end = "")
					if userIn4 == "n":																# Double condition to break the main loop if the user reached a fourth input
						break
					if userIn4 == "y":
						break
				
				elif userIn2 == "11":											# Condition if user selects to cancel the filter
					print("You have jumped back to gif selection.")				# Breaks loop, and brings user back into gif selection or quitting
					break
				else:
					print("Invalid Choice - ", end = "")
		elif userIn == "20":											# User selecting quit, will print this statement
			print("You have selected quit,", end = " ")
		else:															# Condition that will print invalid input if the user did not enter a valid input
			print("Invalid Choice - ", end = "")
		if userIn == "20":												# Condition that will end the main while loop, which will end the program
			print("The program will now close.")
			break
try:													# Runs function main, if there are no errors
	if __name__ == '__main__':
		main()
except ValueError:										# Catches variable value errors
	print("Error: You didn't enter a proper value. The program will now close.")
except:													# Catches all other errors.
	print("An unexcepted error has occured. The program will now close.")
