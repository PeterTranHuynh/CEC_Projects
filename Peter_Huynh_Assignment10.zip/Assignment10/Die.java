/**
	Author: Peter Huynh
	File Name: Die.java
	Assignment: Assignment Ten � Java Die Class
	Description: This is the Die.java file that holds two constructers, two getters, two setter (one private, one public), and a print method. Here is where we randomize our die value based on die side # and amount of dice.
 */
package Assignment10;

import java.util.Random;

public class Die
{
    // instance variables 
    private int myDieValue;
    private int myDieSides;
    private Random myRandom;
    
    // Dice Class Constructors
    public Die()
    {
        // initialize instance variables to default values
    	this.myDieValue = 0;
    	this.myDieSides = 0;
    	this.myRandom = new Random();
    }
    
    public Die(int numSides)
    {
        // initialize value and random as above
        // use setDieValue to set the number of sides
    	this.myDieSides = 0;
    	this.myDieSides = numSides;
    }
    
    // getter methods
    public int getDieSides()
    {
    	return myDieSides;
    }

    public int getDieValue()
    {
        return myDieValue;
    }
    
    // setter methods
    private void setDieSides(int newNumSides)
    {
        // a user of the Die class cannot call this method directly
        //   it is a helper function for the Die Class
    	if(newNumSides <= 100 && newNumSides >= 4)
    	{
    		myDieSides = newNumSides;
    	}
    }
    
    public void rollDie(int numSides)
    {
    	setDieSides(numSides);
    	myDieValue = myRandom.nextInt(myDieSides) + 1;
    }
    
    // other methods
    public void printDice(int dieNum, int numSides)
    {
        /*
         * if dieNum is <= 0, the output does not need to list which die 
         *    is being printed
         *    e.g. "Die Value: 5"
         * else, the output should indicate which die is being
         *    displayed
         *    e.g. "Die 2 Value: 5" is displayed when dieNum is 2
         */
    	if(dieNum <= 0)
    	{
    		System.out.println("Die Value: " + getDieValue());
    	}
    	else
    	{
    		System.out.println("Die " + dieNum + " Value: " + getDieValue());
    	}
    }
}