/**
	Author: Peter Huynh
	File Name: TestDieClass
	Assignment: Assignment Ten � Java Die Class
	Description: This java file is created to test the Die.java file. IT runs through all public methods within the die class.
 */

package Assignment10;

import java.util.Scanner;
import Assignment10.Die;

public class TestDieClass
{
	
	public static int numSides;
	public static int newNumSides;
	public static int dieNum;
	
	public TestDieClass()
	{
		TestDieClass.numSides = 0;
		TestDieClass.newNumSides = 0;
		TestDieClass.dieNum = 0;
	}
	
	
	public static void main(String [] args)
    {
        /*
         * write code to thoroughly test the Die class
         *  that you made in Die.java 
         *  (sometimes this is called exercising your code)
         * 
         * if you create additional methods (optional) make
         *  aure to document them
         */
		Die die = new Die();
		
    	System.out.println("Testing getDieSides output: " + die.getDieSides());
    	System.out.println("Testing getDieValue output: " + die.getDieValue() + "\r\n");
		
    	System.out.println("Testing a default die");
    	die.printDice(dieNum, numSides);
    	
    	System.out.println("\r\nRolling Die");
    	die.rollDie(5);
    	die.printDice(1, 5);
    	
    	System.out.println("\r\nTesting getDieSides output: " + die.getDieSides());
    	System.out.println("Testing getDieValue output: " + die.getDieValue());
    	
		Scanner input1;
    	Scanner input2;
		System.out.println("\r\nLets apply this to a simulation");
		do
    	{
    		System.out.println("How many dice do you want to use?: ");
    		input1 = new Scanner(System.in);
    		dieNum = Integer.parseInt(input1.nextLine());
    		
    		System.out.println("How many sides do you want each die to have?\r\n(Select between 4 and 100): ");
    		input2 = new Scanner(System.in);
    		newNumSides = Integer.parseInt(input2.nextLine());
    		
    		if(newNumSides > 100 || newNumSides < 4)
    		{
    			System.out.println("You did not choose a die size between 4 and 100.\r\nPlease try again.\r\n");
    		}
    		else
    		{
    			die.rollDie(newNumSides);
    			die.printDice(dieNum, newNumSides);
    			input1.close();
    			input2.close();
    		}
    	} while(newNumSides > 100 || newNumSides < 4);
    	
    }
}