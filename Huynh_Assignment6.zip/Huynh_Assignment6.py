"""
Filename: Huynh_Assignment6.py
Assignment Name: Assignment Six – Creatures and Reflections
Author: Peter Tran Huynh

Description:
I decided to make Toad, from the Mario Bros. series, next to a triforce from The Legend of Zelda series.
I found this to be fun and an easily tangible creature to create, and I enjoy them for their popcultural characteristics.
Other than that, I wanted to make something that I would enjoy for myself as well.
Toad and the Triforce is make with 23 shapes, two of which are polygons, and 9 different colors: Red, Blue, Yellow Pink, Tan, Black, White, Grey, and Brown.
"""

from graphics import *

def main():
	Window = GraphWin("Peter Huynh Assignment 6: Creatures and Reflections", 801, 481)		# Graphical Window Variable set at 800x480
	Window.setBackground("White")   	           											# Sets the background color to white, because grey is unappealing.
	
	# Creature Shoes
	C_Shoe1 = Oval(Point(350, 300), Point(390, 350))		# Shoe variable focused on two points.
	C_Shoe1.setFill("Brown")								# Color of shoe.
	C_Shoe1.setOutline("Black")								# Outline of shoe.
	C_Shoe1.draw(Window)									# Draws show onto window
	
	# Creature Shoes cont.
	C_Shoe2 = Oval(Point(410, 300), Point(450, 350))
	C_Shoe2.setFill("Brown")
	C_Shoe2.setOutline("Black")
	C_Shoe2.draw(Window)
	
	# Creature Pants
	C_Pants = Oval(Point(350, 250), Point(450, 330))
	C_Pants.setFill("White")
	C_Pants.setOutline("Black")
	C_Pants.draw(Window)
	
	# Creature Arms
	C_Arm1 = Oval(Point(295, 230), Point(500, 260))
	C_Arm1.setFill("Tan")
	C_Arm1.setOutline("Black")
	C_Arm1.draw(Window)
	
	# Creature Body
	C_Body = Rectangle(Point(350, 200), Point(450, 300))
	C_Body.setFill("Tan")
	C_Body.setOutline("Tan")
	C_Body.draw(Window)
	
	# Creature Body cont.
	C_Body2 = Oval(Point(350, 240), Point(450, 310))
	C_Body2.setFill("Tan")
	C_Body2.setOutline("Black")
	C_Body2.draw(Window)
	
	# Creature Clothing
	C_Cloth = Rectangle(Point(350, 200), Point(375, 310))
	C_Cloth.setFill("Blue")
	C_Cloth.setOutline("Black")
	C_Cloth.draw(Window)
	
	# Creature Clothing cont.
	C_Cloth2 = Rectangle(Point(425, 200), Point(450, 310))
	C_Cloth2.setFill("Blue")
	C_Cloth2.setOutline("Black")
	C_Cloth2.draw(Window)
	
	# Creature Head
	C_Head = Circle(Point(400, 180), 70)
	C_Head.setOutline("Black")
	C_Head.setFill("Tan")
	C_Head.draw(Window)
	
	# Creature Hat
	C_Hat1 = Oval(Point(300, 12), Point(500, 190))
	C_Hat1.setFill("White")
	C_Hat1.draw(Window)
	
	# Creature Hat cont.
	C_Hat2 = Oval(Point(300, 60), Point(325, 140))
	C_Hat2.setFill("Red")
	C_Hat2.setOutline("White")
	C_Hat2.draw(Window)
	
	# Creature Hat cont.
	C_Hat3 = Oval(Point(475, 60), Point(500, 140))
	C_Hat3.setFill("Red")
	C_Hat3.setOutline("White")
	C_Hat3.draw(Window)
	
	# Creature Hat cont.
	C_Hat4 = Oval(Point(475, 60), Point(500, 140))
	C_Hat4.setFill("Red")
	C_Hat4.setOutline("White")
	C_Hat4.draw(Window)
	
	# Creature Hat cont.
	C_Hat5 = Oval(Point(370, 15), Point(430, 35))
	C_Hat5.setFill("Red")
	C_Hat5.setOutline("White")
	C_Hat5.draw(Window)

	# Creature Hat cont.
	C_Hat6 = Circle(Point(400, 115), 50)
	C_Hat6.setFill("Red")
	C_Hat6.setOutline("White")
	C_Hat6.draw(Window)
	
	# Creature Hat cont.
	C_Hat1 = Oval(Point(300, 12), Point(500, 190))
	C_Hat1.setOutline("Black")
	C_Hat1.draw(Window)

	# Creature Eyes
	C_Eyes1 = Oval(Point(363, 190), Point(368, 210))
	C_Eyes1.setFill("Black")
	C_Eyes1.setOutline("Black")
	C_Eyes1.draw(Window)
	
	# Creature Eyes cont.
	C_Eyes2 = Oval(Point(430, 190), Point(435, 210))
	C_Eyes2.setFill("Black")
	C_Eyes2.setOutline("Black")
	C_Eyes2.draw(Window)
	
	# Creature Mouth
	C_Mouth = Circle(Point(400, 220), 25)
	C_Mouth.setFill("Black")
	C_Mouth.setOutline("Black")
	C_Mouth.draw(Window)
	
	# Creature Mouth cont.
	C_Mouth2 = Rectangle(Point(370, 195), Point(425, 220))
	C_Mouth2.setFill("Tan")
	C_Mouth2.setOutline("Tan")
	C_Mouth2.draw(Window)
	
	# Creature Tongue cont.
	C_Tongue = Oval(Point(386, 230), Point(414, 243))
	C_Tongue.setFill("Pink")
	C_Tongue.setOutline("Pink")
	C_Tongue.draw(Window)
	
	# Triforce
	T_1 = Polygon(Point(350, 355), Point(450, 355), Point(400, 430))
	T_1.setFill("Yellow")
	T_1.setOutline("Black")
	T_1.draw(Window)
	
	# Triforce cont.
	T_2 = Polygon(Point(375, 393), Point(425, 393), Point(399, 355))
	T_2.setFill("White")
	T_2.setOutline("Black")
	T_2.draw(Window)
	
	# Name of Creature
	Name = Text(Point(400, 450), "Nintendo - Toad finding a Triforce")
	Name.setFill("Grey")
	Name.draw(Window)

	Window.getMouse()
	Window.close()
	print("Press any key to continue\n")
	
main()
