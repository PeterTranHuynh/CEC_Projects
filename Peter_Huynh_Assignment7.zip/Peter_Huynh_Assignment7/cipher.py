"""
Filename: cipher.py
Assignment Name: Assignment Seven: Ciphers
Author: Peter Tran Huynh
Description: File containing all the functions that encodes and decodes files.
"""
from string import ascii_uppercase as letters
from string import punctuation as symbols
from string import digits
from string import whitespace
from string import *

def caesar_cipher(text, key):
	"""
	Encrypts or Decrypts text using a Caesar cipher with the
	 supplied key value
	Params - text to modify and the key value
	Return - the text modifed by the Caesar cipher
	"""	
	text = remove_chars((text))				# Removes all unwanted characters in text parameter and turns it into uppercase
	codec = create_caesar_codec(key)		# Creates a encoded codec dictionary based on parameter key
	caesar_list = []						# Empty list that will hold the encoded text parameter
	
	for char in text:						# Loops character char in each line of text
		encoded_char = codec[char]			# Sets encoded character to the codec in position / equal to char
		caesar_list.append(encoded_char)	# Adds encoded character into the list that holds the encoded text parameter
		
	return "".join(caesar_list)				# Returns all of encoded text list as a joined string variable
		
def deranged_cipher(text, keyword, toEncrypt):
	"""
	Encrypts or Decrypts text using a deranged alphabet cipher with the
	 supplied secret keyword/phrase.
	Params - text to modify, the keyword cipher text, and whether to encrypt
	Return - the text modifed by the deranged cipher
	"""
	text = remove_chars((text))
	codec = create_deranged_codec(keyword, toEncrypt)
	deranged_list = []
	
	for char in text:
		encoded_char = codec[char]
		deranged_list.append(encoded_char)
		
	return "".join(deranged_list)
	
def remove_duplicate_chars(line):
	"""
	Leaves first occurrence of a character in a string and
	  removes all duplicates of that character
	  e.g., the string 'abcba' becomes 'abc'
			the string 'a b c b a' becomes 'a bc'
	Params - line of text to modify
	Return - the modified string
	"""
	chars = []						# Empty list char
	for c in line:					# For loop for c inside each line of line parameter
		if chars.count(c) < 1:		# Conditional that sees that if there is can c that appear less than once
			chars.append(c)			# Adds c to the list char
	return "".join(chars)			# Returns all of list char as a joined string
	
# I combined the remove symbols, whitespace, and digits into one function, for a shorter file
def remove_chars(line):
	"""
	Removes all punctuation characters in a string
	  e.g., the string '-!00!-' becomes '00'
	Params - line of text to modify
	Return - the modified string
	Removes all whitespace characters in a string
	  e.g., the string '  a b c  b    a' becomes 'abcba'
	Params - line of text to modify
	Return - the modified string
	Removes all digit characters in a string
	  e.g., the string '10dollars10' becomes 'dollars'
	Params - line of text to modify
	Return - the modified string
	"""
	whitelist = 'abcdefghijklmnopqrstuvwxyz' + 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'		# Whitelist variable that indicates what is acceptable to the return
	return (''.join(count for count in line if count in whitelist)).upper()		# Returns a string made of join characters of count, where count is inside line and will only hold characters within whitelist. Also turns everything into uppercase after creating the joined string

def create_caesar_codec(key):
	"""
	Creates a dictionary that maps a normal character to the
	 coded character value after using a caesar cipher
	Params - the key value, which is an integer
	  a positive key shifts forward and negative backward
	Return - the dictionary codec
	"""
	codec = {}									# Empty dictionary called codec
	key = key % 26								# Fixes a key value out of the range -26 to 26
		
	for c in letters:							# Loops character c inside letters, letters is a variable that has A-Z
		chrNum = ord(c) + key					# Sets variable chrNum to the unicode value of c and adds the value of key to it.
		while chrNum > 90 or chrNum < 65:		# Loops until chrNum is more than 90 or less than 65 in value
			if chrNum > 90:						# Condition where chrNum is greater than 90
				chrNum -= 26					# Subtracts 26 from chrNum value.
			elif chrNum < 65:					# Other condition where chrNum is less than 65
				chrNum += 26					# Adds 26 to chrNum value.
		codec[c] = chr(chrNum)					# Adds the character value of the unicode chrNum to list codec at position c.
		
	return codec								# Returns the list codec
	
def create_deranged_codec(keyword, toEncrypt):
	"""
	Creates a dictionary that maps a normal character to the
	 encoded character value after using a deranged cipher
	Params - the key value, which is an integer
	  a positive key shifts forward and negative backward
	Return - the dictionary codec
	"""
	codec = {} 																			# Empty dictionary codec
	keyword = remove_chars(keyword)														# Sets keyword to the return value of remove_chars with parameter keyword
	keycomplete = (remove_duplicate_chars(keyword + 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'))		# Sets keycomplete to the return value of remove_duplicate_chars with the parameter keyword + letters
	
	if toEncrypt == 1:
		for i in range(len(letters)):
			codec[letters[i]] = keycomplete[i]											# Codecs at position similar to letters at position I will be set to keycomplete at position i.
	else:
		for i in range(len(letters)):
			codec[keycomplete[i]] = letters[i]											# Codecs at position similar to keycomplete at position i will be set to letters at position i. 
	return codec
	
def print_cipher_codec(codec):
	"""
	This prints out the contents in the dictionary. It isn't 
	 actually specific to just printing a codec and could
	 print out any dictionary supplied.
	
	Params - The dictionary cipher codec
	Return - None
	"""
	print("\nCipher Codec Contents:")
	
	for c in letters:
		print("key = {} has value = {}".format(c, codec[c]))
	
	print()

def main():
	# you can use the main function for testing and trying out
	#  various things that were left here
	
	nums = "888 dollars 888"
	print(remove_chars(nums))
	
	msg = "Hail Caesar!"
	
	txt = 'a' * 4 + 'b' * 2 + 'c'
	
	txt = remove_duplicate_chars(txt)
	
	print(txt)
	
	key = -26
	emsg = caesar_cipher(msg, key)
	print(msg)
	print(emsg)
	dmsg = caesar_cipher(emsg, -key)
	print(dmsg)
	print()
	
	secret = "..jazz jackrabbit	/?ghijklmnopqrstuvwxyz324"
	msg2 = "The quick brown fox"
	emsg = deranged_cipher(msg2, secret, True)
	print(emsg)
	dmsg = deranged_cipher(emsg, secret, False)
	print(dmsg)
	
	# when the codec creation is working, you can uncomment this
	#  to see the deranged codec values
	#myCodec = create_deranged_codec(secret, True)
	#print_cipher_codec(myCodec)
	
	"""
	
	ws_tests = ["\t\t   ab c  d b		a", ".", "\t", ""]
	
	symbol_tests = ["-!!~~oo~~!!-", "#", "a", "bab", "\t", ""]
	
	dup_tests = [".A B A C B A.", ".", "a", "cba", "\ta\tb", ""]
	
	for i in range(len(ws_tests)):
		result = remove_chars(ws_tests[i])
		print("WS Test {} result: {}".format(i + 1, result))
	print()
	
	for i in range(len(symbol_tests)):
		result = remove_chars(symbol_tests[i])
		print("Sym Test {} result: {}".format(i + 1, result))
	print()
			
	for i in range(len(dup_tests)):
		result = remove_chars(dup_tests[i])
		print("Dup Test {} result: {}".format(i + 1, result))
	print()
	
	codec = create_caesar_codec(2)
	print(codec)
	
	values = codec.values()
	
	for c in letters:
		print("codec[{}] = {}".format(c, codec[c]))
		
	print(len(codec))
	
	rcodec = create_caesar_codec(-2)
	
	for c in letters:
		print("rcodec[{}] = {}".format(c, rcodec[c]))
	
	dcodec = create_deranged_codec("happy joy...to the world", True)
	print(dcodec)
	
	for c in letters:
		print("dcodec[{}] = {}".format(c, dcodec[c]))
		
	rdcodec = create_deranged_codec("happy joy...to the world", False)
		
	for c in letters:
		print("rdcodec[{}] = {}".format(c, rdcodec[c]))
	"""
	
if __name__ == '__main__':
	main()
