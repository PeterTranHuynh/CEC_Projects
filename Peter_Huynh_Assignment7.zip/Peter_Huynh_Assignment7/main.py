"""
Filename: main.py
Assignment Name: Assignment Seven: Ciphers
Author: Peter Tran Huynh
Description: File that encodes and decodes files.
"""
from cipher import *
from string import *

def open_file(filename, mode):
	"""
	Opens a file based on specified mode and returns the file handle
	There is some exception handling to try to keep the program from crashing
	  from file issues
	
	Params - the name of the file and the mode used for opening it
	Return - a file handle for the opened file or None if file could not be opened
	"""
	try:
		if(mode == 'w'):
			file = open(filename, mode)
		elif(mode == 'r'):
			file = open(filename, mode)
		
	except FileNotFoundError:
		print("The file could not be found!")
		return
	except IOError:
		print("An Input/Output error has occurred!")
		print("Aborting program!")
		return
	except:
		print("An unknown error has occurred, sorry!")
		return
	else:	
		return file
	
def ask_for_filenames():
	"""
	Prompts user to enter a filename of a file to encode or decode and
	 also prompts user to enter a filename to store results of encoding / decoding
	
	Params - none
	Return - two filenames that the user enters, first the file
	 to read and second the file to write
	"""
	print("Enter the filename for encoding/decoding: ")
	reading = input()
	print("\nEnter the filename to write results: ")
	writing = input()
	
	return reading, writing

def get_menu_selection():
	"""
	Prints a menu of choices for the user and asks user to enter their choice
	
	Params - none
	Return - a string containing what the user entered
	"""
	print("Welcome to the Amazing Cipher Program!")
	print("1 - Caesar Cipher Encode")
	print("2 - Caesar Cipher Decode")
	print("3 - Deranged Cipher Encode")
	print("4 - Deranged Cipher Decode")
	print("\nEnter your selection: ")
	
	choice = input()
	
	return choice[0]	# returns only the first character entered
	
def main():
	"""
	Runs the cipher program interface, which allows a user to
	 specify a text file, encode or decode the text file using
	 Caesar or Deranged ciphers, and write the results to a 
	 different text file.
	"""
	txt = []															# Empty list txt
	selection = get_menu_selection()
	rfile, wfile = ask_for_filenames()
	infile = open(rfile, "r")
	for l in infile:													# Loops inside infile
		txt.append(l)													# Adds line in infile to the list txt
	
	if infile != None:
		outfile = open(wfile, "w")
		if(selection == '1'):
			key = int(input("\nPlease enter a key value: "))			# Gets an integer value from a user input for key
			for i in txt:												# Loops inside list txt via character i
				outfile.write((caesar_cipher(i, key)) + "\r\n")			# Writes a line in outfile based on a cipher function with a breakline
		elif(selection == '2'):
			key = (int(input("\nPlease enter a key value: ")))
			key = -key
			for i in txt:
				outfile.write((caesar_cipher(i, key)) + "\r\n")	
		elif(selection == '3'):
			toEncrypt = 1												# Sets toEncrypt to 1, for True
			keyword = str(input("\nPlease enter a keyword: "))
			for i in txt:
				outfile.write((deranged_cipher(i, keyword, toEncrypt)) + "\r\n")	
		elif(selection == '4'):
			toEncrypt = 0
			keyword = str(input("\nPlease enter the keyword: "))
			for i in txt:
				outfile.write((deranged_cipher(i, keyword, toEncrypt)) + "\r\n")		
		else:
			print("\nSelection {} is not a valid, I quit!\n".format(selection))
		outfile.close()													# Closes outfile
	infile.close()														# Closes infile
	
if __name__ == '__main__':
	main()
