"""
Filename: Peter_Huynh_Assignment5.py
Assignment Name: Assignment Five: : Foxes & Rabbits Simulation with Files
Author: Peter Tran Huynh
Description: Creates a file that will creat a text file of the similation in assignment 4 / 4.5
"""
import math

def run_simulation():
	# Values in initvals.txt are the constants used in the simulation
	Infile = open("initvals.txt", "r")

	for line in Infile:
		rBr = float(line[ : -1])									# Rabbit birth rate without predation
		fBr = float(Infile.readline().replace('\n', ''))			# Fox birth rate 
		I = float(Infile.readline().replace('\n', ''))				# INTERACT I is the likelihood that a rabbit and fox will meet
		S = float(Infile.readline().replace('\n', ''))				# SUCCESS S is the likelihood that when a fox & rabbit meet that the fox catches the rabbit
	Infile.close()

	# Inputs
	print("Starting Simulation\n")
	R = int(input("Enter the initial rabbit population: "))					# R is the current rabbit population
	print()
	F = int(input("Enter the initial fox population: "))					# F is the current fox population
	print()
	D = int(input("Enter the number of days to run the simulation: "))		# D is the number of days to run the simulation
	print()
	Fr = int(input("Enter the observation frequency: "))					# Fr is how often to display results are written into the text file.
	print()
	Filename = str(input("Enter filename to store results: "))				# Filename is the filename of the text file being modified/created
	print()

	rR, fR, cR = R, R, R	# Rabbit Population values for round, floor, ceiling
	rF, fF, cF = F, F, F	# Fox Population values for round, floor, ceiling

	# The first values in the list are the starting populations entered by the user
	rR_List = [round(rR)]			# Lists to contain the populations from the rounding calculations
	rF_List = [round(rF)]
	fR_List = [math.floor(fR)]		# Lists to contain the populations from the floored calculations
	fF_List = [math.floor(fF)]
	cR_List = [math.ceil(cR)]		# Lists to contain the populations from the ceiling calculations
	cF_List = [math.ceil(cF)]
	R_List = [R]					# Lists to contain the populations from the raw calculations
	F_List = [F]

	for i in range(1, D + 1):
		# Computes the new number of rabbits and foxes for the day and round the results
		chR_r = round(rBr * rR - I * rR * rF)
		chF_r = round(I * S * rR * rF - fBr * rF)
		rR = rR + chR_r
		rF = rF + chF_r
		rR_List.append(round(rR))
		rF_List.append(round(rF))

		# Computes the new number of rabbits and foxes for the day and take the ceiling of results
		chR_c = math.ceil(rBr * cR - I * cR * cF)
		chF_c = math.ceil(I * S * cR * cF - fBr * cF)
		cR = cR + chR_c
		cF = cF + chF_c
		cR_List.append(math.ceil(cR))
		cF_List.append(math.ceil(cF))
		

		# Computes the new number of rabbits and foxes for the day and take the floor of results
		chR_f = math.floor(rBr * fR - I * fR * fF)
		chF_f = math.floor(I * S * fR * fF - fBr * fF)
		fR = fR + chR_f
		fF = fF + chF_f
		fR_List.append(math.floor(fR))
		fF_List.append(math.floor(fF))

		# Computes the new number of rabbits and foxes for the day and leave as a fraction
		chR = (rBr * R - I * R * F)
		chF = (I * S * R * F - fBr * F)
		R = R + chR
		F = F + chF
		R_List.append(R)
		F_List.append(F)
		
	# Calculating all of the averages
	rR_Avg = sum(rR_List[ : ]) / len(rR_List)
	rF_Avg = sum(rF_List[ : ]) / len(rF_List)
	fR_Avg = sum(fR_List[ : ]) / len(fR_List)
	fF_Avg = sum(fF_List[ : ]) / len(fF_List)
	cR_Avg = sum(cR_List[ : ]) / len(cR_List)
	cF_Avg = sum(cF_List[ : ]) / len(cF_List)
	R_Avg = sum(R_List[ : ]) / len(R_List)
	F_Avg = sum(F_List[ : ]) / len(F_List)
	
	# Create/Overwrite
	Outfile = open(((Filename) + ".csv"), "w")

	# Print out the averages
	Outfile.write(", Rounded-Rabbit-Average, Rounded-Rabbit-Averages, , , Floor-Rabbit-Average, Floor-Fox-Average, , , Ceil-Rabbit-Average, Ceil-Fox-Average, , , Raw-Rabbit-Averages, Raw-Fox-Average,\r\n")
	Outfile.write(("{:>1s}{:>1.3f}{:>1s}{:>1.3f}{:>1s}{:>1s}{:>1s}{:>1.3f}{:>1s}{:>1.3f}{:>1s}{:>1s}{:>1s}{:>1.3f}{:>1s}{:>1.3f}{:>1s}{:>1s}{:>1s}{:>1.3f}{:>1s}{:>1.3f}{:>1s}".format(", ", rR_Avg, ", ", rF_Avg, ", ", ", ", ", ", fR_Avg, ", ", fF_Avg, ", ", ", ", ", ", cR_Avg, ", ", cF_Avg, ", ", ", ", ", ", R_Avg, ", ", F_Avg, ", ") + "\r\n"))

	# Table Heading
	# !!!! NOTE !!!!: ',' breaks to a new spreedsheet box in Microsoft Excel, while ' ' breaks to a new box for LibreOffice Calc!
	displayStr = "{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}".format("Day, ", "Rounded-Rabbits, ", "Rounded-Foxes, , ", "Day, ", "Floor-Rabbits, ", "Floor-Foxes, , ", "Day, ", "Ceil-Rabbits, ", "Ceil-Foxes, , ", "Day, ", "Raw-Rabbits, ", "Raw-Foxes, ")
	Outfile.write("\r\n" + (displayStr))

	# Writing loop for table data
	for i in range(0, D + 1, Fr):
		displayStr = "{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1s}{:>1.3f}{:>1s}{:>1.3f}{:>1s}".format(str(i) + ", ", str(rR_List[i]) + ", ", str(rF_List[i]) + ", ", ", ", str(i) + ", ", str(fR_List[i]) + ", ", str(fF_List[i]) + ", ", ", ", str(i) + ", ", str(cR_List[i]) + ", ", str(cF_List[i]) + ", ", ", ", str(i) + ", ", R_List[i], ", ", F_List[i], ", ")
		Outfile.write("\r\n" + (displayStr))
	print(("Simulation Finished - result data written to ") + (Filename) + (".csv."))
	Outfile.close()
	
run_simulation()

